var http = require('http');
var fs = require('fs');
var formidable = require('formidable');

var PlayerName1;
var Player1 = 'X';
var PlayerName2;
var Player2 = 'O';
var PlayerTurn = true;
var gameArray;

http.createServer(function (req,res){
	if(req.url == '/PlayerRegistry'){
		if(PlayerName1 == null){
			var form = new formidable.IncomingForm();
			form.parse(req, function (err, fields, files) {
				PlayerName1 = fields.player;
			res.writeHead(200, {'Content-Type': 'text/html'});
			res.write('<h2>PlayerName1 => ' + PlayerName1 + '</h2>');
			res.write('<h2> Waiting for player Two</h2>');
			res.write('<form action="Game" method="post">');
			res.write('<input type="submit" value="Refresh"></form>');	
			res.end();
			});
		}else if (PlayerName2 == null){
			var form = new formidable.IncomingForm();
			form.parse(req, function (err, fields, files) {
				PlayerName2 = fields.player;
			res.writeHead(200, {'Content-Type': 'text/html'});
			res.write('<h2>PlayerName2 => ' + PlayerName2 + '</h2>');
			res.write('<h2> Waiting for player One</h2>');
			res.write('<form action="Game" method="post">');
			res.write('<input type="submit" value="Refresh"></form>');
			res.end();	
			});			
		}		
	} else if(req.url == '/Game'){
		if(PlayerName1 != null && PlayerName2 !=null){
			var form = new formidable.IncomingForm();
			form.parse(req, function (err, fields, files) {
					var column = fields.col-1;
					
					if(column >=0 && column<=8){
						for(r=5;r>=0;r--){
							if(gameArray[r][column] == '[]' && PlayerTurn == true){
								gameArray[r][column] = '['+Player1+']';
								PlayerTurn = false;
								break;
							}
							if(gameArray[r][column] == '[]' && PlayerTurn == false){
								gameArray[r][column] = '['+Player2+']';
								PlayerTurn = true;
								break;
							}
						}
					}
					checkHorizontal(res);
					checkVertical(res);
					checkDiagonalForward(res);
 			});
			game(res);
		}else{
			if(PlayerName1 != null){
				res.writeHead(200, {'Content-Type': 'text/html'});
				res.write('<h2>PlayerName1 => ' + PlayerName1 + '</h2>');
				res.write('<h2> Waiting for player Two</h2>');
				res.write('<form action="Game" method="post">');
				res.write('<input type="submit" value="Refresh"></form>');	
				res.end();
			}
			if(PlayerName2 != null){
				res.writeHead(200, {'Content-Type': 'text/html'});
				res.write('<h2>PlayerName1 => ' + PlayerName2 + '</h2>');
				res.write('<h2> Waiting for player One</h2>');
				res.write('<form action="Game" method="post">');
				res.write('<input type="submit" value="Refresh"></form>');
				res.end();
			}
			
		}
	}else{
		gameArray = new Array(6);
		for(i=0;i<6;i++)
			gameArray[i] = new Array(9);
		for(k=0;k<6;k++)
			for(p=0;p<9;p++)
				gameArray[k][p] = '[]';		
		res.writeHead(200, {'Content-Type': 'text/html'});
		res.write('<h1>Welcome to 5 in Row Game</h1>');
		res.write('<form action="PlayerRegistry" method="post">');
		res.write('Enter Player name: <input type="text" id="player1" name="player"><br>');
		res.write('<input type="submit"></form>');
		res.end();
	}
}).listen(8080);

function checkHorizontal(res){
	for(d=0;d<6;d++){//column
		for(p=0;p<9;p++){//row
			if(!(p +4 > 8)){
				var symbol = gameArray[d][p];
				if(symbol == '[]'){
					break;
				}else{
					var won = false;
					var count = 0;
					for (ki =p; ki < (p+5); ki++){
						if(gameArray[d][ki] == symbol){
							count++;
						}else{
							count = 0;
						}
						if(count == 5){
							res.writeHead(200, {'Content-Type': 'text/html'});
							res.write('<h2>And the winner is ...</h2>');
							if(symbol == '[X]'){
								res.write('<h1>WINNER = '+ PlayerName1+'</h1>');
							}
							if(symbol == '[O]'){
								res.write('<h1>WINNER = '+ PlayerName2+'</h1>');	
							}
							res.end();
						}
					}
				}
				
			}
		}
	}
}

function checkVertical(res){
	for(d=0;d<6;d++){//column
		for(p=0;p<9;p++){//row
			if(!(d +4 > 5)){
				var symbol = gameArray[d][p];
				if(symbol != '[]'){
					var won = false;
					var count = 0;
					for (ki =d; ki < (d+5); ki++){
						if(gameArray[ki][p] == symbol){
							count++;
						}else{
							count = 0;
						}
						if(count == 5){
							res.writeHead(200, {'Content-Type': 'text/html'});
							res.write('<h2>And the winner is ...</h2>');
							if(symbol == '[X]'){
								res.write('<h1>WINNER = '+ PlayerName1+'</h1>');
							}
							if(symbol == '[O]'){
								res.write('<h1>WINNER = '+ PlayerName2+'</h1>');	
							}
							res.end();
						}
					}
				}
				
			}
		}
	}
}

function checkDiagonalForward(res){
	for(d=0;d<6;d++){//column
		for(p=0;p<9;p++){//row
			if(!(d +4 > 5) && !(p +4 > 8)){
				var symbol = gameArray[d][p];
				if(symbol == '[]'){
					break;
				}else{
					var won = false;
					var count = 0;
					for (ki =0; ki < 5; ki++){
						if(gameArray[d + ki][p + ki] == symbol){
							count++;
						}else{
							count = 0;
						}
						if(count == 5){
							res.writeHead(200, {'Content-Type': 'text/html'});
							res.write('<h2>And the winner is ...</h2>');
							if(symbol == '[X]'){
								res.write('<h1>WINNER = '+ PlayerName1+'</h1>');
							}
							if(symbol == '[O]'){
								res.write('<h1>WINNER = '+ PlayerName2+'</h1>');	
							}
							res.end();
						}
					}
				}
				
			}
		}
	}
}

function game(res){
	var string = '';
	fs.readFile('game.html', function(err, data) {
				res.writeHead(200, {'Content-Type': 'text/html'});
				res.write('<h1>Lets Start the Game</h1>');
				res.write('<h2>PlayerName1 => ' + PlayerName1 + ' Xs</h2>');
				res.write('<h2>PlayerName2 => ' + PlayerName2 + ' Os</h2>');
				if(PlayerTurn == true){
					res.write('<h3>'+ PlayerName1+' - its your turn</h3>');
				}else{
					res.write('<h3>'+ PlayerName2+' - its your turn</h3>');
				}
				
					string += '<p>';
				for(k=0;k<6;k++){
					for(p=0;p<9;p++)
						string += gameArray[k][p] + '      ';	
					string += '</p>';
				}
				res.write(string);
				res.write(data);
				res.end();			
				});
				return string;
}